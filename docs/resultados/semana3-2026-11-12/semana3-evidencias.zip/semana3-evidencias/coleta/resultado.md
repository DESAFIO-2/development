# Comparativo Semana 3 — coleta e diagnósticos

Tipo: **COLETA_REAL**. Dataset: `golden_set_v2_consolidado.jsonl`.
Pares: 22; inválidos: 0.

**Não há conclusão de superioridade nem taxa de alucinação medida.**
Escores lexicais e acerto de rota são heurísticas; citação válida confirma somente metadados.
Controles de segurança/abstenção são separados das chamadas de LLM nos registros por caso.

| Diagnóstico (positivos de pares válidos) | Sem RAG | Com RAG |
| --- | ---: | ---: |
| n_positivos_pares_validos | 18 | 18 |
| rota_correta_heuristica | 0.3889 | 1.0 |
| citacao_metadados_valida | 0.0 | 0.0556 |
| overlap_tokens_contexto | None | 0.6683 |
| overlap_tokens_pergunta | 0.3807 | 0.7234 |
| recall_chunks | 0.0 | 1.0 |
| precision_chunks | 0.0 | 0.5926 |

| Critério ADR 0003 | Valor | Mínimo | Status |
| --- | --- | --- | --- |
| faithfulness_ragas | None | 0.92 | NAO_AVALIADO |
| answer_relevancy_ragas | None | 0.88 | NAO_AVALIADO |
| context_recall_ragas | None | 0.9 | NAO_AVALIADO |
| context_precision_ragas | None | 0.88 | NAO_AVALIADO |

| Caso | Status do par |
| --- | --- |
| GOLD-001 | PAR_LLM |
| GOLD-002 | PAR_LLM |
| GOLD-003 | PAR_LLM |
| GOLD-004 | PAR_LLM |
| GOLD-005 | PAR_LLM |
| GOLD-006 | PAR_LLM |
| GOLD-007 | PAR_LLM |
| GOLD-008 | PAR_LLM |
| GOLD-009 | PAR_LLM |
| GOLD-010 | PAR_LLM |
| GOLD-011 | PAR_LLM |
| GOLD-012 | PAR_LLM |
| GOLD-013 | CONTROLE_DETERMINISTICO |
| GOLD-014 | CONTROLE_DETERMINISTICO |
| GOLD-015 | CONTROLE_DETERMINISTICO |
| GOLD-016 | CONTROLE_DETERMINISTICO |
| GOLD-017 | PAR_LLM |
| GOLD-018 | PAR_LLM |
| GOLD-019 | PAR_LLM |
| GOLD-020 | PAR_LLM |
| GOLD-021 | PAR_LLM |
| GOLD-022 | PAR_LLM |
