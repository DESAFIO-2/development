"""Verifica o pacote e recompõe médias a partir dos checkpoints. Python 3.12+."""
from collections import Counter
from hashlib import sha256
from math import isclose
from pathlib import Path
from statistics import mean
import json

ROOT = Path(__file__).resolve().parent
RUN = ROOT / "coleta"

def read(path):
    return json.loads(path.read_text(encoding="utf-8"))

def digest(obj):
    return sha256(json.dumps(obj, ensure_ascii=False, sort_keys=True, allow_nan=False).encode()).hexdigest()

def require(ok, msg):
    if not ok:
        raise SystemExit(f"FALHA: {msg}")

for line in (ROOT / "SHA256SUMS").read_text().splitlines():
    checksum, name = line.split("  ", 1)
    require(sha256((ROOT / name).read_bytes()).hexdigest() == checksum, name)

collection = read(RUN / "resultado.json")
report = read(RUN / "avaliacao_ragas.json")
judge = RUN / "ragas_v1"
identity = read(judge / "manifesto.json")
snapshot = (RUN / "dataset.jsonl").read_text(encoding="utf-8")
require(digest(snapshot) == read(RUN / "manifesto.json")["dataset_sha256"], "dataset congelado")
require(digest(collection) == identity["coleta_sha256"] == read(
    RUN / "auditoria_factual_humana.json"
)["coleta_sha256"], "vínculo coleta, avaliação e auditoria")
cases = collection["casos"]
require(len(cases) == 22 and [json.loads(line)["id"] for line in snapshot.splitlines() if line.strip()]
        == [case["caso_id"] for case in cases], "identidade dos casos")
require(collection["tipo_execucao"] == "COLETA_REAL" and collection["pares_invalidos"] == 0,
        "coleta real sem pares inválidos")
expected = {"PAR_LLM": 18, "CONTROLE_DETERMINISTICO": 4}
require(Counter(c["status_par"] for c in cases) == expected, "denominadores")
require(len(list((RUN / "geracoes").glob("*.json"))) == 44, "44 checkpoints de geração")
require(len(list((judge / "pares").glob("*.json"))) == 18, "18 checkpoints de pares")
require(len(list((judge / "metricas").glob("*.json"))) == 90, "90 checkpoints de métricas")

scores = {}
for case in cases:
    for arm in ("sem_rag", "com_rag"):
        item = case[arm]
        req = {"case_id": case["caso_id"], "question": item["pergunta"],
               "evidences": item["evidencias"], "rag_mode": arm == "com_rag"}
        checkpoint = read(RUN / "geracoes" / f"{digest(req)}.json")
        value = item["geracao"]
        require(checkpoint["request"] == req and checkpoint["result"] == value
                and checkpoint["result_sha256"] == digest(value), f"{case['caso_id']}/{arm}")
        require(value["provider"] == "ollama_local" and not value["error_code"], "provedor")
        if value["execution_kind"] == "llm":
            metadata = value["provider_metadata"]
            require(metadata["done"] and metadata["eval_count"] > 0
                    and metadata["model"] == "semana3-qwen14", "telemetria Ollama")
    if case["status_par"] != "PAR_LLM":
        continue
    a, b = case["sem_rag"], case["com_rag"]
    q, ref = b["pergunta"], b["referencia"]
    contexts = [h["text"].strip() for h in b["evidencias"] if h["text"].strip()]
    req = dict(pergunta=q, referencia=ref, resposta_sem_rag=a["resposta"],
               resposta_com_rag=b["resposta"], contextos_com_rag=contexts)
    pair = read(judge / "pares" / f"{digest(req)}.json")
    attempts = pair["attempts"]
    require(pair["input"] == req and digest(attempts) == pair["sha256"]
            and len(attempts) == 1 and attempts[0]["error"] is None, f"par {case['caso_id']}")
    inputs = [
        ("sem_rag", "answer_relevancy", dict(user_input=q, response=a["resposta"])),
        ("com_rag", "answer_relevancy", dict(user_input=q, response=b["resposta"])),
        ("com_rag", "faithfulness", dict(user_input=q, response=b["resposta"], retrieved_contexts=contexts)),
        ("com_rag", "context_recall", dict(user_input=q, reference=ref, retrieved_contexts=contexts)),
        ("com_rag", "context_precision", dict(user_input=q, reference=ref, retrieved_contexts=contexts)),
    ]
    for arm, name, args in inputs:
        metric = read(judge / "metricas" / f"{digest([name, args])}.json")
        payload = metric["payload"]
        val = payload["value"]
        require(metric["sha256"] == digest(payload) and payload["input"] == args
                and payload["metric"] == name and 0 <= val <= 1
                and val == attempts[0]["scores"][f"{arm}_{name}"], f"{case['caso_id']}/{arm}/{name}")
        scores.setdefault((arm, name), []).append(val)

print("Pacote íntegro. 44 checkpoints de geração, 18 pares e 90 escores conferidos.")
for (arm, name), vals in scores.items():
    avg = mean(vals)
    require(isclose(avg, report["ragas_oficial"][arm][name], rel_tol=1e-12), f"média {arm}/{name}")
    print(f"{arm:8} {name:17} {avg:.8f}  n={len(vals)}")
delta = [b-a for a,b in zip(scores["sem_rag", "answer_relevancy"],
                             scores["com_rag", "answer_relevancy"], strict=True)]
print(f"Delta pareado de relevância: {mean(delta):.8f}; melhora em {sum(x>0 for x in delta)}/{len(delta)}.")
print(f"Status arquivado: {report['status_entregavel']}")

labels = {case["id"]: set(case["relevant_chunk_ids"])
          for case in map(json.loads, snapshot.splitlines())}
counts = []
for case in cases:
    if case["status_par"] != "PAR_LLM":
        continue
    expected_ids = labels[case["caso_id"]]
    returned_ids = [hit["chunk_id"] for hit in case["com_rag"]["evidencias"]]
    require(expected_ids and 0 < len(returned_ids) <= collection["top_k"]
            and len(returned_ids) == len(set(returned_ids)), "IDs de recuperação")
    counts.append((len(expected_ids.intersection(returned_ids)),
                   len(returned_ids), len(expected_ids)))
hits = sum(hit for hit, _, _ in counts)
returned = sum(size for _, size, _ in counts)
slots = len(counts) * collection["top_k"]
macro = mean(hit / size for hit, size, _ in counts)
recall = mean(hit / size for hit, _, size in counts)
require(isclose(macro, collection["metricas"]["com_rag"]["precision_chunks"], abs_tol=0.00005)
        and isclose(recall, collection["metricas"]["com_rag"]["recall_chunks"], abs_tol=0.00005),
        "diagnóstico por IDs")
print(f"Precisão por IDs (macro): {macro:.4%}; micro: {hits}/{returned} ({hits/returned:.4%}).")
print(f"Precision@3 (fixo): {hits}/{slots} ({hits/slots:.4%}); recall macro: {recall:.4%}.")
